package com.rain.bean;

public class Book {
	private int bid; // id
	private String name; // 图书名称
	private String card; // 图书号
	private String author; // 作者
	private int num; // 图书数量
	private String type; // 图书的分类
	private String press; // 出版社

	public Book() {
		super();
	}

	public int getBid() {
		return bid;
	}

	public void setBid(int bid) {
		this.bid = bid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCard() {
		return card;
	}

	public void setCard(String card) {
		this.card = card;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getPress() {
		return press;
	}

	public void setPress(String press) {
		this.press = press;
	}


	public void printBookInfo() {
		StringBuilder sb = new StringBuilder();
		sb.append("Book Info:\n");
		sb.append("ID: ").append(bid).append("\n");
		sb.append("Name: ").append(name).append("\n");
		sb.append("Card Number: ").append(card).append("\n");
		sb.append("Author: ").append(author).append("\n");
		sb.append("Quantity: ").append(num).append("\n");
		sb.append("Type: ").append(type).append("\n");
		sb.append("Publisher: ").append(press).append("\n");
		System.out.println(sb.toString());
	}


	public boolean isBookAvailable() {
		return num > 0;
	}

	public void updateBookInfo(String newName, String newAuthor, int newNum, String newType, String newPress) {
		this.name = newName;
		this.author = newAuthor;
		this.num = newNum;
		this.type = newType;
		this.press = newPress;
	}
}