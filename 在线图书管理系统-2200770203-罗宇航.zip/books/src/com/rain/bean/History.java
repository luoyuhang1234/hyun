package com.rain.bean;

public class History {
	private int hid; // 借阅记录的id
	private int aid; // 读者的id
	private int bid; // 图书的id
	private String card; // 图书号
	private String bookname; // 图书名称
	private String adminname; // 管理员的账号
	private String username; // 读者的姓名
	private String begintime; // 借阅时间
	private String endtime; // 还书时间
	private int status; // 表示借阅状态，1为正在借阅，2是已经还书

	public History() {
		super();
	}

	public int getHid() {
		return hid;
	}

	public void setHid(int hid) {
		this.hid = hid;
	}

	public int getAid() {
		return aid;
	}

	public void setAid(int aid) {
		this.aid = aid;
	}

	public int getBid() {
		return bid;
	}

	public void setBid(int bid) {
		this.bid = bid;
	}

	public String getCard() {
		return card;
	}

	public void setCard(String card) {
		this.card = card;
	}

	public String getBookname() {
		return bookname;
	}

	public void setBookname(String bookname) {
		this.bookname = bookname;
	}

	public String getAdminname() {
		return adminname;
	}

	public void setAdminname(String adminname) {
		this.adminname = adminname;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getBegintime() {
		return begintime;
	}

	public void setBegintime(String begintime) {
		this.begintime = begintime;
	}

	public String getEndtime() {
		return endtime;
	}

	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public void printHistoryInfo() {
		StringBuilder sb = new StringBuilder();
		sb.append("Borrowing History Info:\n");
		sb.append("Record ID: ").append(hid).append("\n");
		sb.append("Reader ID: ").append(aid).append("\n");
		sb.append("Book ID: ").append(bid).append("\n");
		sb.append("Book Card Number: ").append(card).append("\n");
		sb.append("Book Name: ").append(bookname).append("\n");
		sb.append("Admin Account: ").append(adminname).append("\n");
		sb.append("Reader Name: ").append(username).append("\n");
		sb.append("Borrow Time: ").append(begintime).append("\n");
		sb.append("Return Time: ").append(endtime).append("\n");
		sb.append("Status: ").append(status == 1? "Borrowing" : "Returned").append("\n");
		System.out.println(sb.toString());
	}


	public boolean isBorrowing() {
		return status == 1;
	}

	public void updateBorrowStatus(int newStatus) {
		this.status = newStatus;
	}
}