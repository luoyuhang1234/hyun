package com.rain.bean;

public class TypeBean {
	/**
	 * 图书分类的数据表的bean
	 */
	private int tid; // 分类的id
	private String name; // 分类的名称

	public TypeBean() {
		super();
	}



	public int getTid() {
		return tid;
	}

	public void setTid(int tid) {
		this.tid = tid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public void printTypeInfo() {
		System.out.println("Book Type Info:");
		System.out.println("Type ID: " + tid);
		System.out.println("Type Name: " + name);
	}


	public boolean isValidName(String name) {

		return name != null && !name.trim().isEmpty();
	}

	public void updateTypeName(String newName) {

		if (isValidName(newName)) {
			this.name = newName;
		} else {
			throw new IllegalArgumentException("Invalid type name.");
		}
	}
}