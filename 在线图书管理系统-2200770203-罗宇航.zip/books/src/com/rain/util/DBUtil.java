package com.rain.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBUtil {

	private static final String URL = "jdbc:mysql://127.0.0.1:3306/books?characterEncoding=utf-8&useUnicode=true&useSSL=false&serverTimezone=UTC";
	private static final String USERNAME = "root"; // 建议从配置文件或环境变量中获取
	private static final String PASSWORD = "60079191lyh2004"; // 建议从配置文件或环境变量中获取

	static {
		try {
			// 加载数据库驱动类
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			throw new RuntimeException("Failed to load MySQL driver", e);
		}
	}

	/**
	 * 获取数据库连接
	 *
	 * @return 数据库连接对象
	 */
	public static Connection getConnectDb() {
		try {
			// 使用 DriverManager 获取数据库连接
			return DriverManager.getConnection(URL, USERNAME, PASSWORD);
		} catch (SQLException e) {
			throw new RuntimeException("Failed to connect to the database", e);
		}
	}

	/**
	 * 关闭数据库资源
	 *
	 * @param rs    ResultSet对象，可以为null
	 * @param stm   PreparedStatement对象，可以为null
	 * @param conn  Connection对象，可以为null
	 */
	public static void closeDB(ResultSet rs, PreparedStatement stm, Connection conn) {
		// 尝试关闭ResultSet
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		// 尝试关闭PreparedStatement
		if (stm != null) {
			try {
				stm.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		// 尝试关闭Connection
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public static void CloseDB(ResultSet rs, PreparedStatement stm, Connection conn) {
	}
}