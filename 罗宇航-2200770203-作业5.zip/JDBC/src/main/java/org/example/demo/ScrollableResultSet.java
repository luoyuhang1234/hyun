package org.example.demo;
import java.sql.*;

public class ScrollableResultSet {
    private static final String URL = "jdbc:mysql://localhost:3306/test2";
    private static final String USER = "root";
    private static final String PASSWORD = "60079191lyh2004";

    public static void main(String[] args) {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String sql = "SELECT * FROM teacher";
            rs = stmt.executeQuery(sql);
            rs.last(); // 移动到结果集的最后
            if (rs.getRow() > 1) {
                rs.previous(); // 移动到倒数第二条数据
                System.out.println("ID: " + rs.getInt("id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Course: " + rs.getString("course"));
                System.out.println("Birthday: " + rs.getDate("birthday"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}