package org.example.demo;
import java.sql.*;
import java.util.Calendar;

public class TeacherBatchInsert {
    private static final String URL = "jdbc:mysql://localhost:3306/test2";
    private static final String USER = "root";
    private static final String PASSWORD = "60079191lyh2004";

    public static void main(String[] args) {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
            conn.setAutoCommit(false); // 关闭自动提交

            String insertSQL = "INSERT INTO teacher (id, name, course, birthday) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(insertSQL)) {
                for (int i = 1; i <= 500; i++) {
                    stmt.setInt(1, i);
                    stmt.setString(2, "Teacher " + i);
                    stmt.setString(3, "Course " + i % 10);
                    stmt.setDate(4, new java.sql.Date(Calendar.getInstance().getTimeInMillis() - (365 * 24 * 60 * 60 * 1000 * (500 - i))));
                    stmt.addBatch();

                    if (i % 100 == 0) {
                        stmt.executeBatch(); // 执行批量插入
                        conn.commit(); // 提交事务
                    }
                }
                stmt.executeBatch(); // 执行剩余的批量插入
                conn.commit(); // 提交事务
            }
        } catch (SQLException e) {
            e.printStackTrace();
            try {
                if (conn != null) {
                    conn.rollback(); // 回滚事务
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true); // 恢复自动提交
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}