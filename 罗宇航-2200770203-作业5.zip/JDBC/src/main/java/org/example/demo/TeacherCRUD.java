package org.example.demo;

import java.sql.*;

public class TeacherCRUD {
    private static final String URL = "jdbc:mysql://localhost:3306/test2";
    private static final String USER = "root";
    private static final String PASSWORD = "60079191lyh2004";

    public static void main(String[] args) {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(URL, USER, PASSWORD);

            // Create
            String createSQL = "INSERT INTO teacher (id, name, course, birthday) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(createSQL)) {
                stmt.setInt(1, 1);
                stmt.setString(2, "John Doe");
                stmt.setString(3, "Math");
                stmt.setDate(4, Date.valueOf("1980-01-01"));
                stmt.executeUpdate();
            }

            // Read
            String readSQL = "SELECT * FROM teacher WHERE id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(readSQL)) {
                stmt.setInt(1, 1);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        System.out.println("ID: " + rs.getInt("id"));
                        System.out.println("Name: " + rs.getString("name"));
                        System.out.println("Course: " + rs.getString("course"));
                        System.out.println("Birthday: " + rs.getDate("birthday"));
                    }
                }
            }

            // Update
            String updateSQL = "UPDATE teacher SET name = ? WHERE id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(updateSQL)) {
                stmt.setString(1, "Jane Doe");
                stmt.setInt(2, 1);
                stmt.executeUpdate();
            }

            // Delete
            String deleteSQL = "DELETE FROM teacher WHERE id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(deleteSQL)) {
                stmt.setInt(1, 1);
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

