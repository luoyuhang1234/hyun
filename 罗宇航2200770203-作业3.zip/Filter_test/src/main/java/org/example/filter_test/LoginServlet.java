package org.example.filter_test;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;

// 使用@WebServlet注解来映射URL和Servlet
@WebServlet("/auth")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // doGet方法通常用于获取资源，但在这里我们用它来测试登录表单
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 重定向到登录页面
        response.sendRedirect(request.getContextPath() + "/login");
    }

    // doPost方法处理表单提交
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        System.out.println(username + " " + password);
//        HttpSession session = request.getSession();
//        session.setAttribute("username", username);
//        session.setAttribute("password", password);
        // 调用validateUser方法来验证用户名和密码
        if (validateUser(username, password)) {
            // 登录成功，重定向到受保护的页面
            System.out.println("执行1");
            response.sendRedirect(request.getContextPath() + "/welcome.html");
        } else {
            System.out.println("执行2");
            // 登录失败，重定向回登录页面并显示错误消息
            response.sendRedirect(request.getContextPath() + "/login.jsp");
        }
    }

    // 验证用户名和密码的方法
    private boolean validateUser(String username, String password) {
        // 在实际应用中，这里应该是数据库验证逻辑
        // 并且密码应该使用哈希值进行比较
        // 这里只是一个示例，演示如何验证用户名和密码
        boolean rs = "lyh".equals(username) && "123456".equals(password);
        System.out.println(rs);
        return rs;
    }

}