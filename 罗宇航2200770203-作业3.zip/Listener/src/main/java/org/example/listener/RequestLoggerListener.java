package org.example.listener;

import jakarta.servlet.ServletRequestEvent;
import jakarta.servlet.ServletRequestListener;
import jakarta.servlet.annotation.WebListener;
import jakarta.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import java.util.logging.StreamHandler;
import java.util.logging.LogManager;

@WebListener
public class RequestLoggerListener implements ServletRequestListener {

    private static final Logger logger = Logger.getLogger(RequestLoggerListener.class.getName());

    static {
        try {
            // 设置日志格式
            SimpleFormatter formatter = new SimpleFormatter();
            StreamHandler handler = new StreamHandler();
            handler.setFormatter(formatter);
            logger.addHandler(handler);
            LogManager.getLogManager().addLogger(logger);
            logger.setUseParentHandlers(false);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void requestInitialized(ServletRequestEvent sre) {
        long startTime = System.currentTimeMillis();
        sre.getServletRequest().setAttribute("startTime", startTime);

        // 将 ServletRequest 转换为 HttpServletRequest
        HttpServletRequest request = (HttpServletRequest) sre.getServletRequest();

        String clientIp = request.getRemoteAddr();
        String method = request.getMethod();
        String requestUri = request.getRequestURI();
        String queryString = request.getQueryString() != null ? request.getQueryString() : "N/A";
        String userAgent = request.getHeader("User-Agent");

        logger.info(String.format("=== Request Start ===\n" +
                        "Timestamp: %s\n" +
                        "Client IP: %s\n" +
                        "Request Method: %s\n" +
                        "Request URI: %s\n" +
                        "Query String: %s\n" +
                        "User-Agent: %s\n",
                new Date(), clientIp, method, requestUri, queryString, userAgent));
    }

    @Override
    public void requestDestroyed(ServletRequestEvent sre) {
        long startTime = (Long) sre.getServletRequest().getAttribute("startTime");
        long endTime = System.currentTimeMillis();
        long duration = endTime - startTime;

        logger.info(String.format("=== Request End ===\n" +
                        "Timestamp: %s\n" +
                        "Processing Time: %d ms\n" +
                        "====================",
                new Date(), duration));
    }
}