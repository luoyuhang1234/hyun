USE test1;
/*1. 查询所有学生的信息。*/
SELECT * FROM student;

/*2. 查询所有课程的信息。*/
SELECT * FROM course;

/*3. 查询所有学生的姓名、学号和班级。*/
SELECT name, student_id, my_class FROM student;

/*4. 查询所有教师的姓名和职称。*/
SELECT name, title FROM teacher;

/*5. 查询不同课程的平均分数。*/
SELECT course_id, AVG(score) AS average_score FROM score GROUP BY course_id;

/*6. 查询每个学生的平均分数。*/
SELECT student_id, AVG(score) AS average_score FROM score GROUP BY student_id;

/*7. 查询分数大于85分的学生学号和课程号。*/
SELECT student_id, course_id FROM score WHERE score > 85;

/*8. 查询每门课程的选课人数。*/
SELECT course_id, COUNT(*) AS number_of_students FROM score GROUP BY course_id;

/*9. 查询选修了"高等数学"课程的学生姓名和分数。*/
SELECT s.name, score FROM student s JOIN score sc ON s.student_id = sc.student_id WHERE sc.course_id = 'C001';

/*10. 查询没有选修"大学物理"课程的学生姓名。*/
SELECT name FROM student WHERE student_id NOT IN (SELECT student_id FROM score WHERE course_id = 'C002');

/*11. 查询C001比C002课程成绩高的学生信息及课程分数。*/
SELECT s.name, sc1.score AS math_score, sc2.score AS physics_score FROM student s JOIN score sc1 ON s.student_id = sc1.student_id JOIN score sc2 ON s.student_id = sc2.student_id WHERE sc1.course_id = 'C001' AND sc2.course_id = 'C002' AND sc1.score > sc2.score;

/*11. 统计各科成绩各分数段人数：课程编号，课程名称，[100-85]，[85-70]，[70-60]，[60-0] 及所占百分比。*/
SELECT 
    c.course_id, 
    c.course_name, 
    COUNT(CASE WHEN sc.score BETWEEN 85 AND 100 THEN 1 END) AS score_100_85,
    COUNT(CASE WHEN sc.score BETWEEN 70 AND 84 THEN 1 END) AS score_85_70,
    COUNT(CASE WHEN sc.score BETWEEN 60 AND 69 THEN 1 END) AS score_70_60,
    COUNT(CASE WHEN sc.score < 60 THEN 1 END) AS score_60_0,
    ROUND((COUNT(CASE WHEN sc.score BETWEEN 85 AND 100 THEN 1 END) / COUNT(*)) * 100, 2) AS percent_100_85,
    ROUND((COUNT(CASE WHEN sc.score BETWEEN 70 AND 84 THEN 1 END) / COUNT(*)) * 100, 2) AS percent_85_70,
    ROUND((COUNT(CASE WHEN sc.score BETWEEN 60 AND 69 THEN 1 END) / COUNT(*)) * 100, 2) AS percent_70_60,
    ROUND((COUNT(CASE WHEN sc.score < 60 THEN 1 END) / COUNT(*)) * 100, 2) AS percent_60_0
FROM 
    course c
JOIN 
    score sc ON c.course_id = sc.course_id
GROUP BY 
    c.course_id;
		
		/*12. 查询平均分数最高的学生姓名和平均分数。*/
		SELECT 
    s.name, 
    AVG(sc.score) AS average_score
FROM 
    student s
JOIN 
    score sc ON s.student_id = sc.student_id
GROUP BY 
    s.student_id
ORDER BY 
    average_score DESC
LIMIT 1;

/*15. 查询总分最高的前三名学生的姓名和总分。*/
SELECT 
    s.name, 
    SUM(sc.score) AS total_score
FROM 
    student s
JOIN 
    score sc ON s.student_id = sc.student_id
GROUP BY 
    s.student_id
ORDER BY 
    total_score DESC
LIMIT 3;

/*16. 查询各科成绩最高分、最低分和平均分。*/
SELECT 
    c.course_id, 
    c.course_name, 
    MAX(sc.score) AS highest_score, 
    MIN(sc.score) AS lowest_score, 
    AVG(sc.score) AS average_score,
    ROUND((SUM(CASE WHEN sc.score >= 60 THEN 1 ELSE 0 END) / COUNT(*)) * 100, 2) AS pass_rate,
    ROUND((SUM(CASE WHEN sc.score BETWEEN 70 AND 80 THEN 1 ELSE 0 END) / COUNT(*)) * 100, 2) AS average_rate,
    ROUND((SUM(CASE WHEN sc.score BETWEEN 80 AND 90 THEN 1 ELSE 0 END) / COUNT(*)) * 100, 2) AS good_rate,
    ROUND((SUM(CASE WHEN sc.score >= 90 THEN 1 ELSE 0 END) / COUNT(*)) * 100, 2) AS excellent_rate
FROM 
    course c
JOIN 
    score sc ON c.course_id = sc.course_id
GROUP BY 
    c.course_id
ORDER BY 
    COUNT(*) DESC, 
    c.course_id ASC;
		
/*17. 查询男生和女生的人数。*/
SELECT 
    SUM(CASE WHEN gender = '男' THEN 1 ELSE 0 END) AS male_count,
    SUM(CASE WHEN gender = '女' THEN 1 ELSE 0 END) AS female_count
FROM 
    student;
		
/*18. 查询年龄最大的学生姓名。*/
SELECT 
    name
FROM 
    student
ORDER BY 
    birth_date ASC
LIMIT 1;

/*19. 查询年龄最小的教师姓名。*/
SELECT 
    name
FROM 
    teacher
ORDER BY 
    birth_date DESC
LIMIT 1;

/*20. 查询学过「张教授」授课的同学的信息。*/
SELECT 
    s.*
FROM 
    student s
JOIN 
    score sc ON s.student_id = sc.student_id
JOIN 
    course c ON sc.course_id = c.course_id
JOIN 
    teacher t ON c.teacher_id = t.teacher_id
WHERE 
    t.name = '张教授';
		
/*21. 查询至少有一门课与学号为"2021001"的同学所学相同的同学的信息。*/
SELECT 
    DISTINCT s.*
FROM 
    student s
JOIN 
    score sc ON s.student_id = sc.student_id
WHERE 
    sc.course_id IN (SELECT course_id FROM score WHERE student_id = '2021001') AND s.student_id <> '2021001';
		
/*22. 查询每门课程的平均分数，并按平均分数降序排列。*/
SELECT 
    course_id, 
    AVG(score) AS average_score
FROM 
    score
GROUP BY 
    course_id
ORDER BY 
    average_score DESC;
		
/*23. 查询学号为"2021001"的学生所有课程的分数。*/
SELECT 
    course_id, 
    score
FROM 
    score
WHERE 
    student_id = '2021001';
/*24. 查询所有学生的姓名、选修的课程名称和分数。*/
SELECT 
    s.name, 
    c.course_name, 
    sc.score
FROM 
    student s
JOIN 
    score sc ON s.student_id = sc.student_id
JOIN 
    course c ON sc.course_id = c.course_id;
		
/*25. 查询每个教师所教授课程的平均分数。*/
SELECT 
    t.name, 
    c.course_name, 
    AVG(sc.score) AS average_score
FROM 
    teacher t
JOIN 
    course c ON t.teacher_id = c.teacher_id
JOIN 
    score sc ON c.course_id = sc.course_id
GROUP BY 
    t.teacher_id, 
    c.course_name;
	
/*26. 查询分数在80到90之间的学生姓名和课程名称。*/
SELECT 
    s.name, 
    c.course_name
FROM 
    student s
JOIN 
    score sc ON s.student_id = sc.student_id
JOIN 
    course c ON sc.course_id = c.course_id
WHERE 
    sc.score BETWEEN 80 AND 90;
		
/*27. 查询每个班级的平均分数。*/
SELECT 
    my_class, 
    AVG(score) AS average_score
FROM 
    student s
JOIN 
    score sc ON s.student_id= sc.student_id
GROUP BY
my_class;

/*28. 查询没学过"王讲师"老师讲授的任一门课程的学生姓名。*/
SELECT 
    name
FROM 
    student
WHERE 
    student_id NOT IN (SELECT DISTINCT student_id FROM score AS s JOIN course AS c ON s.course_id = c.course_id JOIN teacher AS t ON c.teacher_id = t.teacher_id WHERE t.name = '王讲师' AND s.student_id = student.student_id);
		
/*29. 查询两门及其以上小于85分的同学的学号，姓名及其平均成绩 。*/
SELECT 
    s.name, 
    s.my_class, 
    SUM(sc.score) AS total_score, 
    (SELECT AVG(sc2.score) FROM score sc2 WHERE sc2.student_id = s.student_id) AS class_avg_score
FROM 
    student s
JOIN 
    score sc ON s.student_id = sc.student_id
GROUP BY 
    s.student_id;
		
/*30. 查询所有学生的总分并按降序排列。*/
SELECT 
    student_id, 
    SUM(score) AS total_score
FROM 
    score
GROUP BY 
    student_id
ORDER BY 
    total_score DESC;
		
/*31. 查询平均分数超过85分的课程名称。*/
SELECT 
    c.course_name
FROM 
    course c
JOIN 
    score sc ON c.course_id = sc.course_id
GROUP BY 
    c.course_id
HAVING 
    AVG(sc.score) > 85;
	
/*32. 查询选修了"高等数学"和"大学物理"的学生姓名。*/
SELECT name
FROM student
WHERE student_id IN (SELECT student_id FROM score WHERE course_id = 'C001')
AND student_id IN (SELECT student_id FROM score WHERE course_id = 'C002');

/*33. 查询分数最高和最低的学生姓名及其分数*/
SELECT s.name, sc.score
FROM student AS s
JOIN score AS sc ON s.student_id = sc.student_id
WHERE sc.score = (SELECT MAX(score) FROM score) OR sc.score = (SELECT MIN(score) FROM score);

/*34.  查询每个班级的最高分和最低分。*/
SELECT s.my_class, MAX(sc.score) AS max_score, MIN(sc.score) AS min_score
FROM student AS s
JOIN score AS sc ON s.student_id = sc.student_id
GROUP BY s.my_class;

/*35. 查询每门课程的优秀率（优秀为90分）。*/
SELECT c.course_name, COUNT(*) AS excellent_count, COUNT(*) / (SELECT COUNT(*) FROM score AS sc2 WHERE sc2.course_id = sc.course_id) AS excellent_rate
FROM score AS sc
JOIN course AS c ON sc.course_id = c.course_id
WHERE sc.score >= 90
GROUP BY sc.course_id;

/*36. 查询平均分数超过班级平均分数的学生。*/
SELECT s.name, s.student_id, AVG(sc.score) AS average_score, (SELECT AVG(sc2.score) FROM score AS sc2 WHERE sc2.student_id IN (SELECT student_id FROM student WHERE my_class = s.my_class) AND sc2.student_id != s.student_id) AS class_average
FROM student AS s
JOIN score AS sc ON s.student_id = sc.student_id
GROUP BY s.student_id
HAVING average_score > class_average;

/*37. 查询每个学生的分数及其与课程平均分的差值。*/
SELECT s.name, c.course_name, sc.score, sc.score - (SELECT AVG(score) FROM score AS sc2 WHERE sc2.course_id = sc.course_id) AS diff
FROM score AS sc
JOIN student AS s ON sc.student_id = s.student_id
JOIN course AS c ON sc.course_id = c.course_id;

/*38. 查询至少有一门课程分数低于80分的学生姓名。*/
SELECT s.name
FROM student AS s
JOIN score AS sc ON s.student_id = sc.student_id
WHERE sc.score < 80;

/*39.  查询所有课程分数都高于85分的学生姓名。*/
SELECT s.name
FROM student AS s
WHERE NOT EXISTS (SELECT * FROM score AS sc WHERE sc.student_id = s.student_id AND sc.score <= 85);

/*40.  查询平均成绩大于等于90分的同学的学生编号和学生姓名和平均成绩。*/
SELECT s.student_id, s.name, AVG(sc.score) AS average_score
FROM student AS s
JOIN score AS sc ON s.student_id = sc.student_id
GROUP BY s.student_id
HAVING average_score >= 90;